package com.cryptotrading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoTradingApplicationTests {

	@Test
	void contextLoads() {
	}

}

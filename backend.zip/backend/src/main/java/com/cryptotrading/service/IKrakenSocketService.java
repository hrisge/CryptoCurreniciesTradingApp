package com.cryptotrading.service;

import com.cryptotrading.api.Data;

public interface IKrakenSocketService {
    public Data getDataByName(final String name);
}
